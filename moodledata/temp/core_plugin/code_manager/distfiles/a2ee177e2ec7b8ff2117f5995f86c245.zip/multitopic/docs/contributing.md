# Multitopic: Contributing Guide ⭐


### Style

Please follow the [Coding Style on MoodleDocs](https://docs.moodle.org/dev/Coding_style)


### Submissions

Submit a pull request onto the develop branch.  Keep your commits small and precise.

Check out the [roadmap](roadmap.md) for things that need doing.