#!/bin/bash
cat > vpl_execution << ENDOFSCRIPT
#!/bin/bash
echo -n "match"
ENDOFSCRIPT
chmod +x vpl_execution