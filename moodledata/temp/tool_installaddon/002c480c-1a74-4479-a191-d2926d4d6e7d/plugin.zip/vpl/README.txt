========================================
VPL - Virtual Programming Lab for Moodle
========================================

   VPL is a programming assignment management system that lets
   students edit and execute programs, and enables automatic and
   continuous assessment.

   This software is distributed under the terms of the GNU General
   Public License version 3 (see http://www.gnu.org/licenses/gpl.txt
   for details)

   This software is provided "AS IS" without a warranty of any kind.

   For more detail access the web site http://vpl.dis.ulpgc.es
